// (c) Copyright 2011-2012, 2023, 2026 Advanced Micro Devices, Inc. All rights reserved.
//
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
//
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
//
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
//
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
////////////////////////////////////////////////////////////
//
// C++ wrapper class for xip_fpo_t providing operator overloading.
// This allows xip_fpo_t to be used with C++ templates that expect
// arithmetic operators (+, -, *, /, =, etc.).
//
// Usage:
//   #include "floating_point_v7_1_bitacc_cmodel_cpp.h"
//   xip_fpo_class a(3.14f);
//   xip_fpo_class b(2.0f);
//   xip_fpo_class c = a * b + a;
//   float result = c.get_flt();
//
// This is analogous to GMP's mpz_class wrapper for mpz_t.
//

#ifndef __xip_fpo_bitacc_cmodel_cpp_h
#define __xip_fpo_bitacc_cmodel_cpp_h

#include "floating_point_v7_1_bitacc_cmodel.h"
#include <iostream>

// Default precision for FP32: 8-bit exponent, 24-bit mantissa (total)
#define XIP_FPO_CLASS_DEFAULT_EXP_PREC  8
#define XIP_FPO_CLASS_DEFAULT_MANT_PREC 24

/**
 * C++ wrapper class for xip_fpo_t with operator overloading.
 * 
 * This class manages the lifetime of an xip_fpo_t value and provides
 * arithmetic operators for natural C++ usage. By default, it uses
 * FP32 precision (8-bit exponent, 24-bit mantissa).
 */
class xip_fpo_class {
private:
    xip_fpo_t value;
    
public:
    //========================================================================
    // Constructors
    //========================================================================
    
    /**
     * Default constructor - creates a zero-initialized FP32 value.
     */
    xip_fpo_class() {
        xip_fpo_init2(value, XIP_FPO_CLASS_DEFAULT_EXP_PREC, XIP_FPO_CLASS_DEFAULT_MANT_PREC);
        xip_fpo_set_d(value, 0.0);
    }
    
    /**
     * Construct from float.
     */
    xip_fpo_class(float f) {
        xip_fpo_init2(value, XIP_FPO_CLASS_DEFAULT_EXP_PREC, XIP_FPO_CLASS_DEFAULT_MANT_PREC);
        xip_fpo_set_flt(value, f);
    }
    
    /**
     * Construct from double.
     */
    xip_fpo_class(double d) {
        xip_fpo_init2(value, XIP_FPO_CLASS_DEFAULT_EXP_PREC, XIP_FPO_CLASS_DEFAULT_MANT_PREC);
        xip_fpo_set_d(value, d);
    }
    
    /**
     * Construct from int.
     */
    xip_fpo_class(int i) {
        xip_fpo_init2(value, XIP_FPO_CLASS_DEFAULT_EXP_PREC, XIP_FPO_CLASS_DEFAULT_MANT_PREC);
        xip_fpo_set_si(value, i);
    }
    
    /**
     * Construct with custom precision.
     */
    xip_fpo_class(xip_fpo_prec_t exp_prec, xip_fpo_prec_t mant_prec) {
        xip_fpo_init2(value, exp_prec, mant_prec);
        xip_fpo_set_d(value, 0.0);
    }
    
    /**
     * Construct with custom precision and initial float value.
     */
    xip_fpo_class(xip_fpo_prec_t exp_prec, xip_fpo_prec_t mant_prec, float f) {
        xip_fpo_init2(value, exp_prec, mant_prec);
        xip_fpo_set_flt(value, f);
    }
    
    /**
     * Copy constructor.
     */
    xip_fpo_class(const xip_fpo_class& other) {
        xip_fpo_init2(value, 
                      xip_fpo_get_prec_exp(const_cast<xip_fpo_ptr>(other.value)),
                      xip_fpo_get_prec_mant(const_cast<xip_fpo_ptr>(other.value)));
        xip_fpo_set(value, other.value);
    }
    
    //========================================================================
    // Destructor
    //========================================================================
    
    /**
     * Destructor - frees the internal xip_fpo_t memory.
     */
    ~xip_fpo_class() {
        xip_fpo_clear(value);
    }
    
    //========================================================================
    // Assignment operators
    //========================================================================
    
    /**
     * Copy assignment operator.
     */
    xip_fpo_class& operator=(const xip_fpo_class& other) {
        if (this != &other) {
            xip_fpo_set(value, other.value);
        }
        return *this;
    }
    
    /**
     * Assignment from float.
     */
    xip_fpo_class& operator=(float f) {
        xip_fpo_set_flt(value, f);
        return *this;
    }
    
    /**
     * Assignment from double.
     */
    xip_fpo_class& operator=(double d) {
        xip_fpo_set_d(value, d);
        return *this;
    }
    
    /**
     * Assignment from int.
     */
    xip_fpo_class& operator=(int i) {
        xip_fpo_set_si(value, i);
        return *this;
    }
    
    //========================================================================
    // Arithmetic operators
    //========================================================================
    
    /**
     * Addition: xip_fpo_class + xip_fpo_class
     */
    xip_fpo_class operator+(const xip_fpo_class& rhs) const {
        xip_fpo_class result;
        xip_fpo_add(result.value, this->value, rhs.value);
        return result;
    }
    
    /**
     * Compound addition: xip_fpo_class += xip_fpo_class
     */
    xip_fpo_class& operator+=(const xip_fpo_class& rhs) {
        xip_fpo_add(value, value, rhs.value);
        return *this;
    }
    
    /**
     * Subtraction: xip_fpo_class - xip_fpo_class
     */
    xip_fpo_class operator-(const xip_fpo_class& rhs) const {
        xip_fpo_class result;
        xip_fpo_sub(result.value, this->value, rhs.value);
        return result;
    }
    
    /**
     * Compound subtraction: xip_fpo_class -= xip_fpo_class
     */
    xip_fpo_class& operator-=(const xip_fpo_class& rhs) {
        xip_fpo_sub(value, value, rhs.value);
        return *this;
    }
    
    /**
     * Multiplication: xip_fpo_class * xip_fpo_class
     */
    xip_fpo_class operator*(const xip_fpo_class& rhs) const {
        xip_fpo_class result;
        xip_fpo_mul(result.value, this->value, rhs.value);
        return result;
    }
    
    /**
     * Compound multiplication: xip_fpo_class *= xip_fpo_class
     */
    xip_fpo_class& operator*=(const xip_fpo_class& rhs) {
        xip_fpo_mul(value, value, rhs.value);
        return *this;
    }
    
    /**
     * Division: xip_fpo_class / xip_fpo_class
     */
    xip_fpo_class operator/(const xip_fpo_class& rhs) const {
        xip_fpo_class result;
        xip_fpo_div(result.value, this->value, rhs.value);
        return result;
    }
    
    /**
     * Compound division: xip_fpo_class /= xip_fpo_class
     */
    xip_fpo_class& operator/=(const xip_fpo_class& rhs) {
        xip_fpo_div(value, value, rhs.value);
        return *this;
    }
    
    /**
     * Unary negation: -xip_fpo_class
     */
    xip_fpo_class operator-() const {
        xip_fpo_class result(*this);
        // Negate by subtracting from zero
        xip_fpo_class zero(0.0f);
        xip_fpo_sub(result.value, zero.value, this->value);
        return result;
    }
    
    //========================================================================
    // Mixed-type arithmetic (xip_fpo_class op double)
    //========================================================================
    
    /**
     * Multiplication: xip_fpo_class * double
     */
    xip_fpo_class operator*(double rhs) const {
        xip_fpo_class rhs_fpo(rhs);
        return *this * rhs_fpo;
    }
    
    /**
     * Addition: xip_fpo_class + double
     */
    xip_fpo_class operator+(double rhs) const {
        xip_fpo_class rhs_fpo(rhs);
        return *this + rhs_fpo;
    }
    
    /**
     * Subtraction: xip_fpo_class - double
     */
    xip_fpo_class operator-(double rhs) const {
        xip_fpo_class rhs_fpo(rhs);
        return *this - rhs_fpo;
    }
    
    /**
     * Division: xip_fpo_class / double
     */
    xip_fpo_class operator/(double rhs) const {
        xip_fpo_class rhs_fpo(rhs);
        return *this / rhs_fpo;
    }
    
    //========================================================================
    // Comparison operators
    //========================================================================
    
    /**
     * Equality comparison.
     */
    bool operator==(const xip_fpo_class& rhs) const {
        int result;
        xip_fpo_equal(&result, this->value, rhs.value);
        return result != 0;
    }
    
    /**
     * Inequality comparison.
     */
    bool operator!=(const xip_fpo_class& rhs) const {
        return !(*this == rhs);
    }
    
    /**
     * Less than comparison.
     */
    bool operator<(const xip_fpo_class& rhs) const {
        int result;
        xip_fpo_less(&result, this->value, rhs.value);
        return result != 0;
    }
    
    /**
     * Less than or equal comparison.
     */
    bool operator<=(const xip_fpo_class& rhs) const {
        int result;
        xip_fpo_lessequal(&result, this->value, rhs.value);
        return result != 0;
    }
    
    /**
     * Greater than comparison.
     */
    bool operator>(const xip_fpo_class& rhs) const {
        int result;
        xip_fpo_greater(&result, this->value, rhs.value);
        return result != 0;
    }
    
    /**
     * Greater than or equal comparison.
     */
    bool operator>=(const xip_fpo_class& rhs) const {
        int result;
        xip_fpo_greaterequal(&result, this->value, rhs.value);
        return result != 0;
    }
    
    //========================================================================
    // Conversion functions
    //========================================================================
    
    /**
     * Convert to float.
     */
    float get_flt() const {
        return xip_fpo_get_flt(value);
    }
    
    /**
     * Convert to double.
     */
    double get_d() const {
        return xip_fpo_get_d(value);
    }
    
    /**
     * Get the underlying xip_fpo_t pointer (const).
     */
    xip_fpo_srcptr get_fpo() const {
        return value;
    }
    
    /**
     * Get the underlying xip_fpo_t pointer (non-const).
     */
    xip_fpo_ptr get_fpo_ptr() {
        return value;
    }
    
    //========================================================================
    // Precision query
    //========================================================================
    
    /**
     * Get exponent precision.
     */
    xip_fpo_prec_t get_prec_exp() const {
        return xip_fpo_get_prec_exp(const_cast<xip_fpo_ptr>(value));
    }
    
    /**
     * Get mantissa precision.
     */
    xip_fpo_prec_t get_prec_mant() const {
        return xip_fpo_get_prec_mant(const_cast<xip_fpo_ptr>(value));
    }
};

//============================================================================
// Non-member operators for mixed-type arithmetic (double op xip_fpo_class)
//============================================================================

/**
 * Multiplication: double * xip_fpo_class
 */
inline xip_fpo_class operator*(double lhs, const xip_fpo_class& rhs) {
    return rhs * lhs;
}

/**
 * Addition: double + xip_fpo_class
 */
inline xip_fpo_class operator+(double lhs, const xip_fpo_class& rhs) {
    return rhs + lhs;
}

/**
 * Subtraction: double - xip_fpo_class
 */
inline xip_fpo_class operator-(double lhs, const xip_fpo_class& rhs) {
    xip_fpo_class lhs_fpo(lhs);
    return lhs_fpo - rhs;
}

/**
 * Division: double / xip_fpo_class
 */
inline xip_fpo_class operator/(double lhs, const xip_fpo_class& rhs) {
    xip_fpo_class lhs_fpo(lhs);
    return lhs_fpo / rhs;
}

//============================================================================
// Stream output operator
//============================================================================

/**
 * Output stream operator for debugging.
 */
inline std::ostream& operator<<(std::ostream& os, const xip_fpo_class& fpo) {
    os << fpo.get_d();
    return os;
}

#endif // __xip_fpo_bitacc_cmodel_cpp_h
